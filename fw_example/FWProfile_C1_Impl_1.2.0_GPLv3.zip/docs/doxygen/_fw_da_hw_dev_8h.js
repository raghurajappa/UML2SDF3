var _fw_da_hw_dev_8h =
[
    [ "HW_DEV_CUR_MAX", "_fw_da_hw_dev_8h.html#ac94d95df2c7cfbe50800e1a900c12764", null ],
    [ "HW_DEV_OFF", "_fw_da_hw_dev_8h.html#a28ac96e2cdf8c3e5160a8f8da2298328", null ],
    [ "HW_DEV_ON", "_fw_da_hw_dev_8h.html#a8ea6e7e49375cc2dada3b9599f421a78", null ],
    [ "HW_DEV_OPER", "_fw_da_hw_dev_8h.html#a88748d9228f698ff4ee22c91c525c44a", null ],
    [ "HW_DEV_SBY", "_fw_da_hw_dev_8h.html#a9824d29718ab8dac8506f1d88cfd5730", null ],
    [ "HW_DEV_TEMP_MAX", "_fw_da_hw_dev_8h.html#a78d434324b462f90fa683288adc903e6", null ],
    [ "TR_HW_DEV_OFF", "_fw_da_hw_dev_8h.html#a99adfaa8faa71fad31ffcf86c6f40c0f", null ],
    [ "TR_HW_DEV_ON", "_fw_da_hw_dev_8h.html#a9904ba6e2687ace8dc69a5ee3be12680", null ],
    [ "TR_HW_DEV_OPER", "_fw_da_hw_dev_8h.html#a0ab0c429f7875eafc2263355e3fc6c06", null ],
    [ "TR_HW_DEV_SBY", "_fw_da_hw_dev_8h.html#a0df69acf23bf72c58e2aceee16c29089", null ],
    [ "GetHwDevCur", "_fw_da_hw_dev_8h.html#a25b7c48d50d745db85472662e24dfe3a", null ],
    [ "GetHwDevSm", "_fw_da_hw_dev_8h.html#a15f3858566edc56c43208bdd59f4c785", null ],
    [ "GetHwDevTemp", "_fw_da_hw_dev_8h.html#aa86e60d27853192f3d39a0b571b21ee5", null ]
];