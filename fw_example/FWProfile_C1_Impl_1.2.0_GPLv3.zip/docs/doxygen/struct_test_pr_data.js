var struct_test_pr_data =
[
    [ "counter_1", "struct_test_pr_data.html#ab7bd53e52a5bf29e3261345cf930b890", null ],
    [ "flag_1", "struct_test_pr_data.html#a2fdeda83a4cb7d4885b0c05d872b1b6a", null ],
    [ "flag_2", "struct_test_pr_data.html#a24dff9eb26952a40eb4115d005a1659a", null ],
    [ "flag_3", "struct_test_pr_data.html#a34f7b238da12e63dc832a550b1d7f97c", null ],
    [ "flag_4", "struct_test_pr_data.html#aa4e0de5f471ec53db277b4a251b1e49e", null ],
    [ "flag_5", "struct_test_pr_data.html#a8f612cad97c6e23c0d4d62debb8c223e", null ],
    [ "flag_6", "struct_test_pr_data.html#aa38ac17671706186661ad3b7bc1c48f7", null ],
    [ "marker", "struct_test_pr_data.html#a55fc502015142062735ebfd18c825354", null ]
];