var struct_pr_base_desc__t =
[
    [ "aNodes", "struct_pr_base_desc__t.html#a9543328c801dfb1a3e731f3d9f2804f0", null ],
    [ "dNodes", "struct_pr_base_desc__t.html#a501c0fbf7cb636cd1395e496d36e8f48", null ],
    [ "flows", "struct_pr_base_desc__t.html#a9bfd6797b6aab859eb9bb3db4dfb3141", null ],
    [ "nOfANodes", "struct_pr_base_desc__t.html#a4cbbaf8204ac0e440b186ba50c67b29b", null ],
    [ "nOfDNodes", "struct_pr_base_desc__t.html#aadfca2234c5cec1bf3d2b550c30ac8e7", null ],
    [ "nOfFlows", "struct_pr_base_desc__t.html#af3c0b32fc8a16fdcb10a9edd2072f273", null ]
];