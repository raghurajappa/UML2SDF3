var _fw_da_delta_check_8h =
[
    [ "HW_DEV_CUR_MAX_DELTA", "_fw_da_delta_check_8h.html#a8896d4ab6493d8f4d343499a1209ff83", null ],
    [ "HW_DEV_DELTA_CNT_LIMIT", "_fw_da_delta_check_8h.html#a981bc5c00b61c5723d5b37e3f25fa5c7", null ],
    [ "HW_DEV_TEMP_MAX_DELTA", "_fw_da_delta_check_8h.html#a8a28f7e1815bae5612c5fed01d2ee5b5", null ],
    [ "GetDeltaCheckSm", "_fw_da_delta_check_8h.html#a26e6ff1def395b488c4257ee817d0c09", null ]
];