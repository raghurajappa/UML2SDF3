var struct_sm_base_desc__t =
[
    [ "cStates", "struct_sm_base_desc__t.html#a4d90d83b729fbfefc66d65d1e0ff20b4", null ],
    [ "nOfCStates", "struct_sm_base_desc__t.html#ab52f35854967b78cd882b959c91687e4", null ],
    [ "nOfPStates", "struct_sm_base_desc__t.html#a054b4e5ca16f9ecb52e977ac00293770", null ],
    [ "nOfTrans", "struct_sm_base_desc__t.html#acdb32cffecee45eb3b8f3a3c046da0db", null ],
    [ "pStates", "struct_sm_base_desc__t.html#ac017138ef9a3bb61b537d9d3c11b6fc2", null ],
    [ "trans", "struct_sm_base_desc__t.html#aaee8d98bf0c180a64d194e4fd4df4f5a", null ]
];