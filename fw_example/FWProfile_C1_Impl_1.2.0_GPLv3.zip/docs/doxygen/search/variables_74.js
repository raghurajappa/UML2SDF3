var searchData=
[
  ['trans',['trans',['../struct_sm_base_desc__t.html#aaee8d98bf0c180a64d194e4fd4df4f5a',1,'SmBaseDesc_t']]],
  ['transcnt',['transCnt',['../struct_fw_sm_desc.html#a0f079a03b08d8fe7a579ffad0ad7f861',1,'FwSmDesc']]]
];
