var struct_f_d_check_data =
[
    [ "cntLimit", "struct_f_d_check_data.html#ac6b1e255ab1348757b71e141421da9cf", null ],
    [ "counter", "struct_f_d_check_data.html#a617a47c70795bcff659815ad0efd2266", null ],
    [ "detectionCheckOutcome", "struct_f_d_check_data.html#a7509c50fc22bf195aee4f0a4dbdae18f", null ],
    [ "fdCheckId", "struct_f_d_check_data.html#ac121f4cd7eae7f2022a58b184b1f9877", null ]
];