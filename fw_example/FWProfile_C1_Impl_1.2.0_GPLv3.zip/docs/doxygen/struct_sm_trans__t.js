var struct_sm_trans__t =
[
    [ "dest", "struct_sm_trans__t.html#a49c9c9258a58d8fb3840928723470e6c", null ],
    [ "id", "struct_sm_trans__t.html#a2f8080631c8a9567a53c3296b5df6362", null ],
    [ "iTrAction", "struct_sm_trans__t.html#af22a2d5ecf293453e02cfeb444d5cd23", null ],
    [ "iTrGuard", "struct_sm_trans__t.html#a250e5c0a58a482d05ffd7c598284dac3", null ]
];