var _fw_da_cur_rec_action_8c =
[
    [ "GetCurRecActionPr", "_fw_da_cur_rec_action_8c.html#a919f2aff9b0e525d0077fe0189d0cc2d", null ],
    [ "HwDevSwitchOff", "_fw_da_cur_rec_action_8c.html#a03dc58e7cd4be5879fbe6a66de598ae4", null ],
    [ "HwDevToStandBy", "_fw_da_cur_rec_action_8c.html#a581ac057dcd0742da413be48d2528ae4", null ],
    [ "WaitN1Cycle", "_fw_da_cur_rec_action_8c.html#ab1d5251abb05238f536684f4e6429fe1", null ]
];