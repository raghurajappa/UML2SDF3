var struct_pr_d_node__t =
[
    [ "nOfOutTrans", "struct_pr_d_node__t.html#acdad797cdb63e66bddfc2f99c7abbee5", null ],
    [ "outFlowIndex", "struct_pr_d_node__t.html#a020bf58ccb0b7d588519ff21f251129f", null ]
];